#!/bin/zsh

ROOT="$HOME/JiJiLite"
BACKUP_DIR="$ROOT/backups"

mkdir -p "$BACKUP_DIR"

STAMP=$(date +"%Y%m%d-%H%M%S")

tar -czf "$BACKUP_DIR/jiji-$STAMP.tar.gz" \
    --exclude="$BACKUP_DIR" \
    -C "$ROOT" .

echo "===================================="
echo " JiJi Lite Backup"
echo "===================================="
echo
echo "Backup berhasil dibuat:"
echo "$BACKUP_DIR/jiji-$STAMP.tar.gz"
